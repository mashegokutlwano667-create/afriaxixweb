import { Link } from "@tanstack/react-router";
import { Mail, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-border mt-24">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary to-violet">
                <span className="text-sm font-black text-white">A</span>
              </span>
              <span className="font-display text-xl font-bold">AfriAxis</span>
            </div>
            <p className="mt-4 max-w-md text-sm text-muted-foreground">
              Building Africa's next generation of intelligent digital solutions —
              AI, software, cloud, and enterprise transformation.
            </p>
            <div className="mt-6 flex flex-col gap-2 text-sm text-muted-foreground">
              <a href="mailto:mashegokutlwano667@gmail.com" className="inline-flex items-center gap-2 hover:text-foreground"><Mail size={14}/> mashegokutlwano667@gmail.com</a>
              <a href="tel:+27846224761" className="inline-flex items-center gap-2 hover:text-foreground"><Phone size={14}/> 084 622 4761</a>
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a className="hover:text-foreground" href="/#services">Artificial Intelligence</a></li>
              <li><a className="hover:text-foreground" href="/#services">Software Engineering</a></li>
              <li><a className="hover:text-foreground" href="/#services">Cloud &amp; DevOps</a></li>
              <li><a className="hover:text-foreground" href="/#services">Cybersecurity</a></li>
              <li><a className="hover:text-foreground" href="/#services">Automation</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a className="hover:text-foreground" href="/#about">About</a></li>
              <li><a className="hover:text-foreground" href="/#work">Case Studies</a></li>
              <li><a className="hover:text-foreground" href="/#impact">The Great Pivot</a></li>
              <li><a className="hover:text-foreground" href="/#insights">Insights</a></li>
              <li><Link className="hover:text-foreground" to="/contact">Contact</Link></li>
              <li><a className="hover:text-foreground" href="#">Privacy</a></li>
              <li><a className="hover:text-foreground" href="#">Terms</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-border pt-6 md:flex-row md:items-center">
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} AfriAxis. All rights reserved.</p>
          <p className="text-xs text-muted-foreground">Made in South Africa · Delivered globally</p>
        </div>
      </div>
    </footer>
  );
}
