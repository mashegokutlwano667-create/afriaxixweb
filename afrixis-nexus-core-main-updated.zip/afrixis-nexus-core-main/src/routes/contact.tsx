import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Mail, Phone, MapPin, Calendar } from "lucide-react";
import { Nav } from "../components/site/Nav";
import { Footer } from "../components/site/Footer";
import { Reveal } from "../components/site/Reveal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — AfriAxis" },
      { name: "description", content: "Start your AI, software or cloud project with AfriAxis. We respond within one business day." },
      { property: "og:title", content: "Contact AfriAxis" },
      { property: "og:description", content: "Talk to our engineering team about your next enterprise project." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <div className="min-h-screen">
      <Nav />
      <section className="relative pt-32 pb-20">
        <div className="absolute inset-0 -z-10 mesh-bg opacity-70" />
        <div className="mx-auto max-w-7xl px-6">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-electric">Contact</div>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="mt-3 max-w-3xl font-display text-5xl font-bold leading-[1.05] md:text-6xl">
              Let's build your <span className="text-gradient">next system.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              Tell us about your project. Our senior team will get back within one business day.
            </p>
          </Reveal>

          <div className="mt-14 grid gap-8 lg:grid-cols-5">
            <div className="lg:col-span-3">
              <Reveal delay={0.15}>
                <form
                  onSubmit={(e) => { e.preventDefault(); setSent(true); }}
                  className="glass rounded-3xl p-8"
                >
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Full name" name="name" placeholder="Jane Dlamini" required />
                    <Field label="Work email" name="email" type="email" placeholder="jane@company.com" required />
                    <Field label="Company" name="company" placeholder="Company Ltd." />
                    <Field label="Phone" name="phone" placeholder="+27 …" />
                  </div>
                  <div className="mt-5">
                    <label className="mb-2 block text-xs font-medium uppercase tracking-widest text-muted-foreground">
                      What are you looking to build?
                    </label>
                    <textarea
                      required
                      rows={5}
                      placeholder="A quick description of your project, goals and timeline."
                      className="w-full rounded-xl border border-input bg-background/50 px-4 py-3 text-sm outline-none transition focus:border-electric focus:ring-2 focus:ring-electric/30"
                    />
                  </div>
                  <div className="mt-6 flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">We reply within 1 business day.</p>
                    <button className="btn-primary inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
                      Send enquiry <ArrowRight size={16} />
                    </button>
                  </div>
                  {sent && (
                    <div className="mt-5 rounded-xl border border-electric/30 bg-electric/10 px-4 py-3 text-sm text-electric">
                      Thanks — your enquiry has been received. We'll be in touch shortly.
                    </div>
                  )}
                </form>
              </Reveal>
            </div>

            <div className="lg:col-span-2 space-y-4">
              <InfoCard icon={<Mail size={18} />} label="Email" value="mashegokutlwano667@gmail.com" href="mailto:mashegokutlwano667@gmail.com" />
              <InfoCard icon={<Phone size={18} />} label="Phone" value="084 622 4761" href="tel:+27846224761" />
              <InfoCard icon={<MapPin size={18} />} label="Office" value="Johannesburg, South Africa" />
              <InfoCard icon={<Calendar size={18} />} label="Book a call" value="Schedule a 30-min discovery" href="#" />
              <div className="glass overflow-hidden rounded-2xl">
                <iframe
                  title="Map"
                  className="h-64 w-full grayscale-[40%] opacity-90"
                  src="https://www.google.com/maps?q=Johannesburg%2C%20South%20Africa&output=embed"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}

function Field({ label, name, type = "text", placeholder, required }: {
  label: string; name: string; type?: string; placeholder?: string; required?: boolean;
}) {
  return (
    <div>
      <label className="mb-2 block text-xs font-medium uppercase tracking-widest text-muted-foreground">{label}</label>
      <input
        name={name} type={type} placeholder={placeholder} required={required}
        className="w-full rounded-xl border border-input bg-background/50 px-4 py-3 text-sm outline-none transition focus:border-electric focus:ring-2 focus:ring-electric/30"
      />
    </div>
  );
}

function InfoCard({ icon, label, value, href }: { icon: React.ReactNode; label: string; value: string; href?: string }) {
  const inner = (
    <div className="card-hover glass flex items-center gap-4 rounded-2xl p-5">
      <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary/25 to-violet/15 text-electric">
        {icon}
      </div>
      <div>
        <div className="text-xs uppercase tracking-widest text-muted-foreground">{label}</div>
        <div className="mt-0.5 text-sm font-medium">{value}</div>
      </div>
    </div>
  );
  return href ? <a href={href}>{inner}</a> : inner;
}
