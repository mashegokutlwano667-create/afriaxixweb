import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import {
  ArrowRight, ArrowUpRight, Brain, Code2, Cloud, LineChart, ShieldCheck,
  Workflow, Sparkles, Check, Compass, Palette, Building2, Truck, Stethoscope,
  GraduationCap, Pickaxe, Factory, Landmark, ShieldAlert, ShoppingBag, Home as HomeIcon,
  Hotel, Zap, Quote, ChevronRight, Rocket, Signal, TrendingUp, MapPin,
} from "lucide-react";
import heroBg from "../assets/hero-network.jpg";
import { Nav } from "../components/site/Nav";
import { Footer } from "../components/site/Footer";
import { Reveal } from "../components/site/Reveal";
import { Counter } from "../components/site/Counter";

export const Route = createFileRoute("/")({
  component: Home,
});

const stats = [
  { label: "AI Projects Delivered", value: 120, suffix: "+" },
  { label: "Countries Served", value: 14, suffix: "" },
  { label: "Enterprise Clients", value: 45, suffix: "+" },
  { label: "Cloud Solutions Shipped", value: 200, suffix: "+" },
  { label: "Years of Experience", value: 12, suffix: "" },
];

const services = [
  {
    icon: Brain,
    title: "Artificial Intelligence",
    desc: "AI agents, LLM integration, computer vision, predictive analytics, document intelligence.",
    items: ["AI Agents", "Chatbots", "LLM Integration", "Computer Vision", "Predictive Analytics", "Document Intelligence"],
  },
  {
    icon: Code2,
    title: "Software Engineering",
    desc: "Enterprise applications, SaaS platforms, web, mobile, APIs and internal business systems.",
    items: ["Enterprise Apps", "SaaS Platforms", "Web Applications", "Mobile Apps", "APIs & Microservices", "Internal Systems"],
  },
  {
    icon: Cloud,
    title: "Cloud & DevOps",
    desc: "AWS, Azure, GCP, Kubernetes, CI/CD and infrastructure automation at enterprise scale.",
    items: ["AWS · Azure · GCP", "Kubernetes", "Docker", "CI/CD Pipelines", "Terraform", "Infra Automation"],
  },
  {
    icon: LineChart,
    title: "Data & Analytics",
    desc: "Dashboards, business intelligence, warehousing and executive reporting.",
    items: ["Power BI", "Dashboards", "Reporting", "Data Warehousing", "ETL Pipelines", "Governance"],
  },
  {
    icon: ShieldCheck,
    title: "Cybersecurity",
    desc: "Risk assessments, audits, compliance, identity and cloud security.",
    items: ["Risk Assessments", "Security Audits", "Compliance", "Identity Management", "Cloud Security", "Zero Trust"],
  },
  {
    icon: Workflow,
    title: "Automation",
    desc: "Business process automation, RPA, CRM & ERP integrations and workflow orchestration.",
    items: ["BPA", "RPA", "CRM Integration", "ERP Integration", "Workflow Automation", "iPaaS"],
  },
  {
    icon: Palette,
    title: "Digital Experience",
    desc: "Award-worthy web design, UI/UX, e-commerce and interactive brand experiences.",
    items: ["Web Design", "UI/UX", "Corporate Websites", "E-Commerce", "Interactive", "Brand Systems"],
  },
  {
    icon: Compass,
    title: "Enterprise Consulting",
    desc: "Digital transformation strategy, architecture reviews and modernization roadmaps.",
    items: ["Strategy", "Architecture", "Modernization", "M&A Tech DD", "Cost Optimization", "Governance"],
  },
];

const industries = [
  { icon: Landmark, label: "Government" },
  { icon: Truck, label: "Logistics" },
  { icon: Stethoscope, label: "Healthcare" },
  { icon: GraduationCap, label: "Education" },
  { icon: Pickaxe, label: "Mining" },
  { icon: Factory, label: "Manufacturing" },
  { icon: Building2, label: "Finance" },
  { icon: ShieldAlert, label: "Insurance" },
  { icon: ShoppingBag, label: "Retail" },
  { icon: HomeIcon, label: "Real Estate" },
  { icon: Hotel, label: "Hospitality" },
  { icon: Zap, label: "Energy" },
];

const projects = [
  {
    title: "Enterprise Operations Dashboard",
    tag: "Data · Cloud",
    challenge: "Fragmented reporting across 40+ business units.",
    solution: "Unified real-time dashboard on Azure with role-based analytics.",
    tech: ["Azure", "React", "Power BI", "PostgreSQL"],
    outcome: "-63% reporting time · +2× decision velocity",
  },
  {
    title: "AI Property Management Platform",
    tag: "AI · SaaS",
    challenge: "Manual property listings and inefficient tenant matching.",
    solution: "AI copilots, computer-vision listing intake and automated marketing.",
    tech: ["Next.js", "OpenAI", "LangChain", "Supabase"],
    outcome: "+318% qualified leads · -70% admin overhead",
  },
  {
    title: "AI Marketing Engine",
    tag: "AI · Automation",
    challenge: "High content demand across paid, organic and social channels.",
    solution: "End-to-end AI content pipeline with brand-safe guardrails.",
    tech: ["Python", "Anthropic", "n8n", "S3"],
    outcome: "10× content throughput · brand-consistent output",
  },
  {
    title: "Cloud Migration & Modernization",
    tag: "Cloud · DevOps",
    challenge: "Legacy monolith with slow releases and high downtime risk.",
    solution: "Containerized microservices on EKS with GitOps CI/CD.",
    tech: ["AWS", "Kubernetes", "Terraform", "ArgoCD"],
    outcome: "99.99% uptime · 12× deploy frequency",
  },
  {
    title: "Mobile Field Inspection App",
    tag: "Mobile · Offline-first",
    challenge: "Field inspections stuck on paper across remote sites.",
    solution: "Offline-first mobile app with sync and AI-assisted defect detection.",
    tech: ["React Native", "Node.js", "Vision AI"],
    outcome: "-58% inspection time · zero data loss",
  },
  {
    title: "Document Intelligence Platform",
    tag: "AI · Enterprise",
    challenge: "Millions of legacy PDFs blocking compliance workflows.",
    solution: "OCR + LLM extraction with human-in-the-loop review.",
    tech: ["Python", "LangChain", "Postgres", "Redis"],
    outcome: "94% extraction accuracy · weeks → hours",
  },
];

const aiCapabilities = [
  "Image Generation", "Video Generation", "AI Voice", "Virtual Assistants",
  "Knowledge Bases", "Business Copilots", "Document Processing", "Marketing Automation",
  "AI Sales Assistants", "Lead Qualification", "Property Walkthroughs",
  "Content Generation", "Enterprise Search",
];

const stack = [
  "AWS", "Azure", "Google Cloud", "React", "Next.js", "Node.js", "Python",
  "PostgreSQL", "MongoDB", "Docker", "Kubernetes", "OpenAI", "Anthropic",
  "LangChain", "Firebase", "Supabase", "Stripe", "GitHub", "Terraform",
];

const processSteps = [
  { n: "01", title: "Discover", desc: "Deep-dive workshops to map goals, constraints and success metrics." },
  { n: "02", title: "Design", desc: "Architecture, UX and delivery plan built for scale and speed." },
  { n: "03", title: "Develop", desc: "Senior engineers ship iteratively with continuous quality gates." },
  { n: "04", title: "Deploy", desc: "Automated CI/CD, observability and hardened cloud rollout." },
  { n: "05", title: "Scale", desc: "Optimize cost, performance, security and product intelligence." },
];

const hubGrowth = [
  { year: "Year 1", hubs: 30 },
  { year: "Year 3", hubs: 150 },
  { year: "Year 5", hubs: 350 },
];

const sdgs = [
  { n: "4", label: "Quality Education" },
  { n: "8", label: "Decent Work & Growth" },
  { n: "9", label: "Industry & Innovation" },
  { n: "10", label: "Reduced Inequalities" },
];

const pivotStack = [
  "React Native", "Next.js", "Node.js · Express", "PostgreSQL", "AWS · Azure",
  "PayFast · Ozow", "Africa's Talking USSD/SMS", "Cell C MVNO API",
];

const testimonials = [
  {
    quote: "AfriAxis rebuilt our operations stack in weeks — not quarters. The engineering bar is genuinely world-class.",
    author: "COO", role: "Pan-African Logistics Group",
  },
  {
    quote: "They shipped an AI copilot that our sales team actually uses every day. Real outcomes, not slideware.",
    author: "CRO", role: "Enterprise SaaS",
  },
  {
    quote: "Best partner we've had for cloud modernization. Pragmatic, senior, and relentlessly focused on delivery.",
    author: "CTO", role: "Financial Services",
  },
];

function Home() {
  return (
    <div className="relative min-h-screen">
      <Nav />
      <Hero />
      <LogosStrip />
      <Solutions />
      <Services />
      <Industries />
      <Work />
      <Impact />
      <AISection />
      <StackMarquee />
      <ProcessSection />
      <Testimonials />
      <WhyAfriAxis />
      <Insights />
      <CTA />
      <Footer />
    </div>
  );
}

/* ---------------- Hero ---------------- */
function Hero() {
  return (
    <section className="relative isolate overflow-hidden pt-32 pb-28 md:pt-40 md:pb-36">
      <div className="absolute inset-0 -z-10">
        <img
          src={heroBg}
          alt=""
          width={1920}
          height={1280}
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
        <div className="absolute inset-0 mesh-bg" />
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="animate-float absolute left-[12%] top-[22%] h-2.5 w-2.5 rounded-full bg-electric shadow-[0_0_16px_var(--color-electric)]" />
        <div className="animate-float absolute right-[18%] top-[35%] h-2 w-2 rounded-full bg-violet shadow-[0_0_16px_var(--color-violet)]" style={{ animationDelay: "1.2s" }} />
        <div className="animate-float absolute left-[28%] top-[65%] h-1.5 w-1.5 rounded-full bg-electric shadow-[0_0_12px_var(--color-electric)]" style={{ animationDelay: "2.4s" }} />
        <div className="animate-float absolute right-[30%] top-[15%] h-1.5 w-1.5 rounded-full bg-violet shadow-[0_0_12px_var(--color-violet)]" style={{ animationDelay: "0.6s" }} />
      </div>

      <div className="mx-auto max-w-7xl px-6">
        <Reveal>
          <div className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-electric shadow-[0_0_12px_var(--color-electric)]" />
            South Africa · Delivering enterprise AI worldwide
          </div>
        </Reveal>

        <Reveal delay={0.05}>
          <h1 className="mt-6 max-w-5xl font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
            Building <span className="text-gradient">Africa's Next Generation</span> of Intelligent Digital Solutions
          </h1>
        </Reveal>

        <Reveal delay={0.1}>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            AfriAxis helps organisations modernise operations through AI, cloud engineering,
            software development, automation and enterprise technology consulting.
          </p>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link to="/contact" className="btn-primary group inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
              Start Your Project <ArrowRight size={16} className="transition-transform group-hover:translate-x-0.5" />
            </Link>
            <a href="#services" className="btn-ghost inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
              Explore Services
            </a>
          </div>
        </Reveal>

        <Reveal delay={0.2}>
          <dl className="mt-16 grid grid-cols-2 gap-6 border-t border-border pt-10 sm:grid-cols-3 lg:grid-cols-5">
            {stats.map((s) => (
              <div key={s.label}>
                <dt className="text-xs uppercase tracking-widest text-muted-foreground">{s.label}</dt>
                <dd className="mt-2 font-display text-3xl font-bold md:text-4xl">
                  <Counter to={s.value} suffix={s.suffix} />
                </dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------- Logos strip ---------------- */
function LogosStrip() {
  const items = ["Palantir-grade delivery", "Vercel-level DX", "Stripe-quality APIs", "Accenture scope", "IBM consulting depth", "OpenAI-native AI"];
  return (
    <section className="border-y border-border/60 py-6">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-10 gap-y-3 px-6 text-xs uppercase tracking-widest text-muted-foreground">
        {items.map((i) => <span key={i}>{i}</span>)}
      </div>
    </section>
  );
}

/* ---------------- Solutions ---------------- */
function Solutions() {
  const cards = [
    { icon: Brain, title: "AI Solutions", desc: "From LLM copilots to computer vision — production-grade AI, not demos." },
    { icon: Code2, title: "Custom Software", desc: "Enterprise systems built by senior engineers with a bias for shipping." },
    { icon: Cloud, title: "Cloud Platforms", desc: "Modern, secure, cost-efficient cloud architectures on AWS, Azure and GCP." },
    { icon: Workflow, title: "Automation", desc: "Remove manual work with orchestrated automation across your stack." },
  ];
  return (
    <section id="solutions" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Solutions"
          title={<>Enterprise capability, <span className="text-gradient">start-up velocity</span></>}
          sub="One partner across AI, software, cloud and transformation — engineered to move as fast as your ambition."
        />
        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <Reveal key={c.title} delay={i * 0.05}>
              <div className="card-hover glass h-full rounded-2xl p-6">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary/30 to-violet/20 text-electric">
                  <c.icon size={20} />
                </div>
                <h3 className="mt-5 font-display text-lg font-semibold">{c.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{c.desc}</p>
                <div className="mt-6 inline-flex items-center text-sm text-electric">
                  Learn more <ChevronRight size={14} className="ml-0.5" />
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Services ---------------- */
function Services() {
  return (
    <section id="services" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Services"
          title={<>Full-stack engineering for the <span className="text-gradient">AI era</span></>}
          sub="Deep expertise across every layer of the modern enterprise stack."
        />
        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={(i % 4) * 0.05}>
              <div className="card-hover glass h-full rounded-2xl p-6">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary/25 to-violet/15 text-electric">
                  <s.icon size={20} />
                </div>
                <h3 className="mt-5 font-display text-lg font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                <ul className="mt-5 space-y-1.5">
                  {s.items.map((it) => (
                    <li key={it} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Check size={12} className="text-electric" /> {it}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Industries ---------------- */
function Industries() {
  return (
    <section id="industries" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Industries"
          title={<>Trusted across <span className="text-gradient">regulated, complex sectors</span></>}
          sub="From mining to healthcare, government to fintech — we ship where uptime and compliance matter."
        />
        <div className="mt-14 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {industries.map((i, idx) => (
            <Reveal key={i.label} delay={(idx % 6) * 0.03}>
              <div className="card-hover glass flex flex-col items-center justify-center gap-3 rounded-2xl p-6 text-center">
                <i.icon size={22} className="text-electric" />
                <span className="text-sm font-medium">{i.label}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Featured Work ---------------- */
function Work() {
  return (
    <section id="work" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Case Studies"
          title={<>Outcomes over <span className="text-gradient">output</span></>}
          sub="A selection of enterprise engagements — each measured by business impact, not lines of code."
        />
        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {projects.map((p, i) => (
            <Reveal key={p.title} delay={(i % 2) * 0.06}>
              <article className="card-hover glass group relative overflow-hidden rounded-3xl p-8">
                <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/20 blur-3xl transition-opacity group-hover:opacity-100 opacity-60" />
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-widest text-electric">{p.tag}</span>
                  <ArrowUpRight size={18} className="text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </div>
                <h3 className="mt-4 font-display text-2xl font-bold">{p.title}</h3>

                <dl className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
                  <div>
                    <dt className="text-xs uppercase tracking-widest text-muted-foreground">Challenge</dt>
                    <dd className="mt-1 text-foreground/90">{p.challenge}</dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-widest text-muted-foreground">Solution</dt>
                    <dd className="mt-1 text-foreground/90">{p.solution}</dd>
                  </div>
                </dl>

                <div className="mt-6 flex flex-wrap gap-2">
                  {p.tech.map((t) => (
                    <span key={t} className="rounded-full border border-border bg-white/[0.03] px-2.5 py-1 text-xs text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="mt-6 rounded-xl border border-border/70 bg-gradient-to-r from-primary/10 to-violet/10 px-4 py-3 text-sm">
                  <span className="text-electric font-medium">Outcome ·</span> {p.outcome}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Impact: The Great Pivot ---------------- */
function Impact() {
  return (
    <section id="impact" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Flagship Initiative"
          title={<>Engineering <span className="text-gradient">The Great Pivot</span></>}
          sub="Beyond client engagements, AfriAxis is building its own venture — proof of the same engineering bar we bring to every project."
        />

        <Reveal delay={0.05}>
          <div className="relative mt-14 overflow-hidden rounded-[2rem] border border-border glass-strong p-8 md:p-14">
            <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-primary/25 blur-3xl" />
            <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-violet/25 blur-3xl" />

            <div className="relative grid gap-12 lg:grid-cols-2 lg:items-start">
              {/* Story + programs */}
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-electric/40 bg-electric/10 px-3 py-1 text-xs text-electric">
                  <Rocket size={12} /> Pilot launch targeted April 2026
                </div>

                <p className="mt-5 text-base leading-relaxed text-foreground/90">
                  <strong className="font-semibold">The Great Pivot</strong> is a dual-entity venture pairing a
                  for-profit mobile network with a non-profit digital-literacy foundation under one brand — closing
                  the gap for South Africa's 13.6 million offline citizens and the roughly 85% of African youth who
                  never receive structured digital training.
                </p>

                <div className="mt-8 grid gap-4 sm:grid-cols-2">
                  <div className="card-hover glass rounded-2xl p-5">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary/30 to-violet/20 text-electric">
                      <Signal size={18} />
                    </div>
                    <h4 className="mt-4 font-display font-semibold">The Great Pivot (Pty) Ltd</h4>
                    <p className="mt-1.5 text-sm text-muted-foreground">
                      For-profit MVNO operating franchised "Digital Innovation Hubs" across underserved communities.
                    </p>
                    <p className="mt-3 text-xs uppercase tracking-widest text-electric">
                      ZAR 3,000 / hub / mo + 8% revenue share
                    </p>
                  </div>
                  <div className="card-hover glass rounded-2xl p-5">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary/30 to-violet/20 text-electric">
                      <GraduationCap size={18} />
                    </div>
                    <h4 className="mt-4 font-display font-semibold">Pivot Africa Foundation</h4>
                    <p className="mt-1.5 text-sm text-muted-foreground">
                      Non-profit digital-literacy arm delivering courses and facilitator certification.
                    </p>
                    <p className="mt-3 text-xs uppercase tracking-widest text-electric">
                      ZAR 250 / student · ZAR 1,200 / facilitator cert
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-2">
                  {sdgs.map((s) => (
                    <div key={s.n} className="flex items-center gap-2 rounded-full border border-border bg-white/[0.03] px-3 py-1.5 text-xs text-muted-foreground">
                      <span className="grid h-5 w-5 place-items-center rounded-full bg-electric/20 text-[10px] font-bold text-electric">
                        {s.n}
                      </span>
                      SDG {s.n} · {s.label}
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-wrap gap-2">
                  {pivotStack.map((t) => (
                    <span key={t} className="rounded-full border border-border bg-white/[0.03] px-2.5 py-1 text-xs text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Chart + network map */}
              <div>
                <div className="glass rounded-2xl p-6">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                      Hub network scale target
                    </h4>
                    <TrendingUp size={16} className="text-electric" />
                  </div>
                  <div className="mt-4 h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={hubGrowth} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                        <defs>
                          <linearGradient id="pivotBarGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="oklch(0.68 0.21 258)" />
                            <stop offset="100%" stopColor="oklch(0.62 0.24 295)" />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.08)" vertical={false} />
                        <XAxis dataKey="year" stroke="oklch(0.68 0.02 258)" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="oklch(0.68 0.02 258)" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip
                          cursor={{ fill: "oklch(1 0 0 / 0.04)" }}
                          contentStyle={{ background: "oklch(0.19 0.014 262)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12, fontSize: 12 }}
                          labelStyle={{ color: "oklch(0.98 0.003 250)" }}
                        />
                        <Bar dataKey="hubs" name="Digital Innovation Hubs" fill="url(#pivotBarGradient)" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-2 text-center text-xs text-muted-foreground">
                    Digital Innovation Hubs — Year 1 → Year 5, scaling pan-African from Year 4
                  </p>
                </div>

                <div className="mt-5 glass rounded-2xl p-6">
                  <NetworkMap />
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function NetworkMap() {
  const nodes = [
    { x: 40, y: 60 }, { x: 120, y: 30 }, { x: 210, y: 70 }, { x: 290, y: 35 },
    { x: 80, y: 130 }, { x: 170, y: 150 }, { x: 250, y: 120 }, { x: 330, y: 90 },
  ];
  const edges = [[0, 1], [1, 2], [2, 3], [0, 4], [4, 5], [5, 6], [6, 2], [6, 7], [3, 7]];
  return (
    <div>
      <div className="flex items-center justify-between">
        <h4 className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Hub coverage network
        </h4>
        <MapPin size={16} className="text-electric" />
      </div>
      <svg viewBox="0 0 360 180" className="mt-4 h-40 w-full" fill="none">
        {edges.map(([a, b], i) => (
          <line
            key={i}
            x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
            stroke="oklch(0.62 0.22 258 / 0.35)" strokeWidth={1.5}
          />
        ))}
        {nodes.map((n, i) => (
          <circle
            key={i}
            cx={n.x} cy={n.y} r={i % 3 === 0 ? 6 : 4}
            fill={i % 3 === 0 ? "oklch(0.68 0.21 258)" : "oklch(0.62 0.24 295)"}
            className="animate-float"
            style={{ animationDelay: `${i * 0.4}s`, transformOrigin: `${n.x}px ${n.y}px` }}
          />
        ))}
      </svg>
      <p className="mt-1 text-xs text-muted-foreground">Illustrative franchise footprint as hubs scale nationwide</p>
    </div>
  );
}

/* ---------------- AI Section ---------------- */
function AISection() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="relative overflow-hidden rounded-[2rem] border border-border glass-strong p-10 md:p-16">
          <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-primary/25 blur-3xl" />
          <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-violet/25 blur-3xl" />

          <Reveal>
            <div className="inline-flex items-center gap-2 rounded-full border border-electric/40 bg-electric/10 px-3 py-1 text-xs text-electric">
              <Sparkles size={12} /> AfriAxis AI
            </div>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-4 max-w-3xl font-display text-4xl font-bold md:text-5xl">
              AI capabilities, <span className="text-gradient">productionised</span>.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-4 max-w-2xl text-muted-foreground">
              We turn frontier AI into reliable business systems — with the observability, safety and integration required for the enterprise.
            </p>
          </Reveal>

          <div className="relative mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {aiCapabilities.map((c, i) => (
              <Reveal key={c} delay={(i % 6) * 0.03}>
                <div className="card-hover flex items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3.5">
                  <span className="text-sm">{c}</span>
                  <Sparkles size={14} className="text-electric" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Stack marquee ---------------- */
function StackMarquee() {
  const loop = [...stack, ...stack];
  return (
    <section className="relative py-20">
      <div className="mx-auto max-w-7xl px-6">
        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground">Our technology stack</p>
      </div>
      <div className="relative mt-8 overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_15%,black_85%,transparent)]">
        <div className="flex w-max animate-marquee gap-3">
          {loop.map((t, i) => (
            <div key={i} className="glass rounded-full px-5 py-2.5 text-sm text-foreground/80 whitespace-nowrap">
              {t}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Process ---------------- */
function ProcessSection() {
  return (
    <section id="about" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Process"
          title={<>A delivery model built to <span className="text-gradient">de-risk</span> your project</>}
          sub="Senior teams, transparent milestones, measurable outcomes."
        />
        <div className="relative mt-16">
          <div className="absolute left-0 right-0 top-1/2 hidden h-px -translate-y-1/2 bg-gradient-to-r from-transparent via-border to-transparent lg:block" />
          <div className="grid gap-6 lg:grid-cols-5">
            {processSteps.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.06}>
                <div className="card-hover glass relative h-full rounded-2xl p-6">
                  <div className="font-display text-3xl font-bold text-gradient">{s.n}</div>
                  <h3 className="mt-2 font-display text-lg font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Testimonials ---------------- */
function Testimonials() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Testimonials"
          title={<>Trusted by <span className="text-gradient">operators who ship</span></>}
        />
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={i} delay={i * 0.06}>
              <figure className="card-hover glass h-full rounded-2xl p-7">
                <Quote size={22} className="text-electric" />
                <blockquote className="mt-4 text-base leading-relaxed text-foreground/90">
                  "{t.quote}"
                </blockquote>
                <figcaption className="mt-6 border-t border-border pt-4 text-sm">
                  <div className="font-semibold">{t.author}</div>
                  <div className="text-muted-foreground">{t.role}</div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Why AfriAxis ---------------- */
function WhyAfriAxis() {
  const rows = [
    { label: "Senior engineers", afri: true, agency: false, free: false },
    { label: "Deep AI expertise", afri: true, agency: false, free: "sometimes" },
    { label: "Cloud-native architecture", afri: true, agency: "limited", free: false },
    { label: "Enterprise delivery model", afri: true, agency: "limited", free: false },
    { label: "End-to-end capability", afri: true, agency: "limited", free: false },
    { label: "Rapid, iterative delivery", afri: true, agency: false, free: "sometimes" },
    { label: "Scalable long-term partner", afri: true, agency: "sometimes", free: false },
  ];
  const Cell = ({ v }: { v: boolean | string }) => {
    if (v === true) return <Check size={16} className="mx-auto text-electric" />;
    if (v === false) return <span className="text-muted-foreground">—</span>;
    return <span className="text-muted-foreground text-xs uppercase tracking-wider">{v as string}</span>;
  };
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHead
          eyebrow="Why AfriAxis"
          title={<>Not an agency. Not freelancers. <span className="text-gradient">An engineering partner.</span></>}
        />
        <Reveal delay={0.05}>
          <div className="mt-12 overflow-hidden rounded-2xl border border-border glass">
            <div className="grid grid-cols-4 border-b border-border bg-white/[0.02] px-6 py-4 text-xs uppercase tracking-widest text-muted-foreground">
              <div className="col-span-1"></div>
              <div className="text-center font-semibold text-foreground">AfriAxis</div>
              <div className="text-center">Traditional Agency</div>
              <div className="text-center">Freelancers</div>
            </div>
            {rows.map((r, i) => (
              <div key={r.label} className={`grid grid-cols-4 px-6 py-4 text-sm ${i % 2 ? "bg-white/[0.015]" : ""}`}>
                <div className="col-span-1">{r.label}</div>
                <div className="text-center"><Cell v={r.afri} /></div>
                <div className="text-center"><Cell v={r.agency} /></div>
                <div className="text-center"><Cell v={r.free} /></div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------- Insights ---------------- */
function Insights() {
  const posts = [
    { cat: "AI", title: "Deploying LLM copilots your team actually uses", read: "6 min" },
    { cat: "Cloud", title: "The pragmatic path to Kubernetes at mid-market scale", read: "8 min" },
    { cat: "Transformation", title: "How to run a modernization program without stalling the business", read: "10 min" },
  ];
  return (
    <section id="insights" className="relative py-28">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHead
          eyebrow="Insights"
          title={<>Fresh thinking on <span className="text-gradient">AI, cloud & transformation</span></>}
        />
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {posts.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.05}>
              <a href="#" className="card-hover glass block h-full rounded-2xl p-7">
                <div className="flex items-center justify-between text-xs uppercase tracking-widest">
                  <span className="text-electric">{p.cat}</span>
                  <span className="text-muted-foreground">{p.read} read</span>
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold leading-snug">{p.title}</h3>
                <div className="mt-6 inline-flex items-center text-sm text-electric">
                  Read article <ChevronRight size={14} className="ml-0.5" />
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- CTA ---------------- */
function CTA() {
  return (
    <section className="relative py-28">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative overflow-hidden rounded-[2rem] border border-border p-12 md:p-16"
          style={{ backgroundImage: "linear-gradient(135deg, oklch(0.24 0.06 262), oklch(0.18 0.06 300))" }}
        >
          <div className="pointer-events-none absolute inset-0 mesh-bg opacity-70" />
          <div className="relative z-10 flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="max-w-2xl font-display text-4xl font-bold md:text-5xl">
                Ready to build something <span className="text-gradient">exceptional?</span>
              </h2>
              <p className="mt-4 max-w-xl text-muted-foreground">
                Tell us about your project. We'll respond within one business day with a concrete plan.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link to="/contact" className="btn-primary inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
                Start a project <ArrowRight size={16} />
              </Link>
              <a href="mailto:mashegokutlwano667@gmail.com" className="btn-ghost inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
                Email us
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------------- Section head ---------------- */
function SectionHead({
  eyebrow, title, sub,
}: { eyebrow: string; title: React.ReactNode; sub?: string }) {
  return (
    <div className="max-w-3xl">
      <Reveal>
        <div className="text-xs uppercase tracking-[0.25em] text-electric">{eyebrow}</div>
      </Reveal>
      <Reveal delay={0.05}>
        <h2 className="mt-3 font-display text-4xl font-bold leading-[1.1] md:text-5xl">{title}</h2>
      </Reveal>
      {sub && (
        <Reveal delay={0.1}>
          <p className="mt-4 text-lg text-muted-foreground">{sub}</p>
        </Reveal>
      )}
    </div>
  );
}
